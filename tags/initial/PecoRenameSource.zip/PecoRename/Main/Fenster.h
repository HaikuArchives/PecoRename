#ifndef FENSTER_H
#define FENSTER_H

#include <Window.h>
#include <Path.h>
#include <ListView.h>

#include "MainView.h"
#include "FileListItem.h"

class Fenster : public BWindow {
	public:
				Fenster();
		bool	QuitRequested();
		void	MessageReceived( BMessage* msg );
		void 	RefsReceived(BMessage *msg);
	private:
		void	Help();
};

#endif