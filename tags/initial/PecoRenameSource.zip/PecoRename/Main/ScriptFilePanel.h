#ifndef SCRIPT_FILE_PANEL_H
#define SCRIPT_FILE_PANEL_H

#include <FilePanel.h>

class ScriptFilePanel : public BFilePanel {
	public:
					ScriptFilePanel();
};

#endif