#ifndef TOP_VIEW_H
#define TOP_VIEW_H

#include <Box.h>
#include <Button.h>

class TopView : public BBox {
	public:
					TopView( BRect frame );
		void		AttachedToWindow();
		BPicture*	CreateButton(float width, const char* text, int mode);
};

#endif