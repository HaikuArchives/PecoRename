#ifndef RENAMER_H
#define RENAMER_H

#include <View.h>
#include <String.h>
#include <Rect.h>
#include <List.h>

#include "constants.h"

class Renamer : public BView {
	public:
							Renamer();
		virtual void		RenameList(BList *FileList);
		void				Draw(BRect updateRect);
		
		const char			*fName;
		int32				fNumberOfItems;
};

#endif