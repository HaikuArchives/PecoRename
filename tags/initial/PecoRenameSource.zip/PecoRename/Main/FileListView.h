#include <ListView.h>

class FileListView : public BListView {
public:
					FileListView(BRect frame);
	virtual void	MouseDown(BPoint where);
	virtual	void	KeyDown(const char *bytes, int32 numBytes);
	virtual bool	InitiateDrag(BPoint pt, int32 itemIndex, bool initialySelected);
};
