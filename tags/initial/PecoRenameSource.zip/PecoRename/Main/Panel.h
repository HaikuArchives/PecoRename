#ifndef PANEL_H
#define PANEL_H

#include <FilePanel.h>

class Panel : public BFilePanel {
	public:
					Panel();
};

#endif