#ifndef REMOVE_H
#define REMOVE_H

#include <iostream.h>

#include <MenuField.h>

#include "Renamer.h"

class LiveTextControl;

class Renamer_Remove : public Renamer {
	public:
				Renamer_Remove();
		void	RenameList(BList *FileList);

		void	DetachedFromWindow();
		void	AttachedToWindow();

	private:
		LiveTextControl		*fPosition1, *fPosition2;
		BMenuField			*fDirection1, *fDirection2;
};

#endif