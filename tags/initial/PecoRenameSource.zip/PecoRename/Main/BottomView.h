#ifndef BOTTOM_VIEW_H
#define BOTTOM_VIEW_H

#include <Box.h>

#include "Renamer.h"

class BottomView : public BBox {
	public:
				BottomView( BRect frame );
				~BottomView();
				
		void 	AttachedToWindow();
};

#endif