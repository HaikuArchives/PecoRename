#ifndef MAIN_VIEW_H
#define MAIN_VIEW_H

#include <View.h>

class MainView : public BView {
	public:
					MainView( BRect frame );
};

#endif