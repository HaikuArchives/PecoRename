#include "functions.h"

int main() {
	PecoApp	myApp;
	myApp.Run();
	return 0;
}