#ifndef UPPERLOWER_H
#define UPPERLOWER_H

#include <iostream.h>

#include <MenuField.h>

#include "Renamer.h"

class Renamer_UpperLower : public Renamer {
	public:
						Renamer_UpperLower();
			void		RenameList(BList *FileList);

			void		AttachedToWindow();
			void		DetachedFromWindow();


	private:
		BMenuField			*fUpperOrLower;
};

#endif