#ifndef PECO_APP_H
#define PECO_APP_H

#include <Application.h>
#include <Path.h>

#include "constants.h"

class Fenster;
class Renamer;

class PecoApp : public BApplication {
	public:
						PecoApp();
		virtual bool	QuitRequested();
		virtual void	MessageReceived(BMessage *msg);
		virtual void	RefsReceived(BMessage *msg);
		virtual void	ReadyToRun();
		virtual	void	AboutRequested();

		Fenster			*fWindow;
		BListView		*fListView;
		BList			*fList;
		BFilePanel		*fFilePanel, *fScriptFilePanel;
		BPath			fPfad;
		int32			fRenameMode;
		BStatusBar		*fStatusBar;
		Renamer			*fRenamers[MODE_TOTAL];

	private:
		void			New();
		bool			NothingToDo();
		void			CreateScript(BMessage *msg);
		void			DoIt();
		void			ChangeRenamer();
		void 			NoRenamer();
};

#endif